package com.codewithmosh.builder.html;

public class HtmlElement {
}
