package com.codewithmosh.abstractFactory;

public class WeighLossMealPlan implements MealPlan {
}
