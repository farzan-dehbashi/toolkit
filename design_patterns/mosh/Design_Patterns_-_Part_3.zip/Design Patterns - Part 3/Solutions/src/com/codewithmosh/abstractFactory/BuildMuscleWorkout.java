package com.codewithmosh.abstractFactory;

public class BuildMuscleWorkout implements WorkoutPlan {
}
