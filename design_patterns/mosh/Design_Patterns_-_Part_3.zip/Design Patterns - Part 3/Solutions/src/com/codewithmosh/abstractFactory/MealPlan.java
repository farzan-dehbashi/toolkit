package com.codewithmosh.abstractFactory;

public interface MealPlan {
}
