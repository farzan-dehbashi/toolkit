package com.codewithmosh.factory;

public class Event {
}
