package com.codewithmosh.abstractFactory;

public class WeightLossWorkout implements WorkoutPlan {
}
