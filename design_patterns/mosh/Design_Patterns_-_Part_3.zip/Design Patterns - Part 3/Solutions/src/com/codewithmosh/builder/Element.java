package com.codewithmosh.builder;

public interface Element {
}
