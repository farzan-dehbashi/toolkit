package com.codewithmosh.builder;

public enum ExportFormat {
    HTML,
    TEXT,
    PDF,
}
