package com.codewithmosh.abstractFactory;

public class BuildMuscleMealPlan implements MealPlan {
}
