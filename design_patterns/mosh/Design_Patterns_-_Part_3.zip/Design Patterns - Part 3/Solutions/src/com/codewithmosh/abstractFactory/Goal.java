package com.codewithmosh.abstractFactory;

public enum Goal {
    WEIGHT_LOSS,
    BUILD_MUSCLE,
    STRENGTH_TRAINING
}
