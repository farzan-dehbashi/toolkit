package com.codewithmosh.prototype;

public class Audio implements Component {
}
