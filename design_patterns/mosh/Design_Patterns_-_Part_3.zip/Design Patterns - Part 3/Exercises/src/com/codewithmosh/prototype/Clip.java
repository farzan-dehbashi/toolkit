package com.codewithmosh.prototype;

public class Clip implements Component {
}
