package com.codewithmosh.prototype;

public interface Component {
}
