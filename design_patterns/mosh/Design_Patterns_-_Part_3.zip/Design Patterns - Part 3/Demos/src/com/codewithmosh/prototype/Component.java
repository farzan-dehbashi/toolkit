package com.codewithmosh.prototype;

public interface Component {
  void render();
  Component clone();
}
