package com.codewithmosh.abstractFactory;

public interface TextBox extends Widget {
}
