package com.codewithmosh.builder;

public interface PresentationBuilder {
  void addSlide(Slide slide);
}
