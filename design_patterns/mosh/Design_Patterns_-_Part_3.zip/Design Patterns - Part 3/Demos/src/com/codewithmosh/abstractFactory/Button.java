package com.codewithmosh.abstractFactory;

public interface Button extends Widget {
}
