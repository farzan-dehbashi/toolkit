package com.codewithmosh.abstractFactory;

public interface Widget {
  void render();
}
