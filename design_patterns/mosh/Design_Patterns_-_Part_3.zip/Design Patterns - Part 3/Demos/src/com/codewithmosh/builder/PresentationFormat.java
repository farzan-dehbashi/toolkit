package com.codewithmosh.builder;

public enum PresentationFormat {
  PDF,
  IMAGE,
  POWERPOINT,
  MOVIE
}
