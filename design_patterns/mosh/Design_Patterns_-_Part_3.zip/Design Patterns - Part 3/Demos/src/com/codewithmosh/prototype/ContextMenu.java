package com.codewithmosh.prototype;

public class ContextMenu {
  public void duplicate(Component component) {
    Component newComponent = component.clone();
    // Add target to our document
  }
}
