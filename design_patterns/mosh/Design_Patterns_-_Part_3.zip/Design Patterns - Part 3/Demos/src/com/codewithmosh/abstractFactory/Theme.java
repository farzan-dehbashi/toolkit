package com.codewithmosh.abstractFactory;

public enum Theme {
  MATERIAL,
  ANT
}
