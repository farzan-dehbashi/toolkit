def convert():
    print("Converting pdf to text...")
